<?php

require "config.php";

class Database {

	private $connection;
	
	function Database() {
        	$this->connection = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    	}

	public function saveVote($vote){
		$query = mysqli_query($this->connection, "INSERT INTO `votes` (`vote`) VALUES ('$vote')") or die(mysql_error());
       		//mysqli_query($this->connection, $query);
	}

	public function getVotesCount(){
		$query = mysqli_query($this->connection, "SELECT count(*) as numberOfVotes FROM `votes`");
        $row = mysqli_fetch_assoc($query);
        return $row['numberOfVotes'];
	}

	public function getGroupVotes($limit){
		$query = mysqli_query($this->connection, "SELECT vote FROM `votes` order by id desc limit $limit");
		$data = array();
		while($row = mysqli_fetch_assoc($query)){
            		$data[] = intval($row['vote']);
        	}
        $full = 0;
        $empty = 0;
        foreach ($data as $v) {
        	if($v == 1){
        		$full++;
        	}else{
        		$empty++;
        	}
        }
        $res = array();
        array_push($res, $full);
        array_push($res, $empty);
        return $res;
	}

	public function getVotesFilterFullCount(){
		$query = mysqli_query($this->connection, "SELECT count(*) as numberOfVotes FROM `votes` WHERE `vote` = true");
        $row = mysqli_fetch_assoc($query);
        return $row['numberOfVotes'];
	}

	public function getVotesFilterEmptyCount(){
		$query = mysqli_query($this->connection, "SELECT count(*) as numberOfVotes FROM `votes` WHERE `vote` = false");
        $row = mysqli_fetch_assoc($query);
        return $row['numberOfVotes'];
	}
	
	public function storeImage($data){
		$query = mysqli_query($this->connection, "INSERT INTO `groups` (`data`) VALUES ('$data')") or die(mysql_error());
       		mysqli_query($this->connection, $query);
	}
	
	public function getImages(){
		$query = mysqli_query($this->connection, "SELECT data FROM `groups`");
		$data = array();
		while($row = mysqli_fetch_assoc($query)){
            		$data[] = $row['data'];
        	}
        	return $data;
	}

}

$method = $_GET['method'];

$database = new Database();

if($method == 'vote'){
	$database->saveVote($_GET['vote']);
}else if($method == 'count'){
	echo json_encode($database->getVotesCount());
}else if($method == 'screenshot'){
	$database->storeImage($_POST['data']);
}else if($method == 'full'){
	echo json_encode($database->getVotesFilterFullCount());
}else if($method == 'group'){
	echo json_encode($database->getGroupVotes($_GET['size']));
}else if($method == 'empty'){
	echo json_encode($database->getVotesFilterEmptyCount());
}

?>