window.requestAnimFrame = (function(){
  return  window.requestAnimationFrame       ||
          window.webkitRequestAnimationFrame ||
          window.mozRequestAnimationFrame    ||
          function( callback ){
            window.setTimeout(callback, 1000 / 60);
          };
})();


var votes;
var groupSize = 10;

$(document).ready(function(){
	$.when(Api.totalCount(), Api.fullCount(), Api.emptyCount())
		.done(function(total, full, empty){
			Api.groupCount((JSON.parse(total[0]) % groupSize)).done(function(data){
				var currentGroup = JSON.parse(data);
				Animation.start(currentGroup[1]/groupSize);
				votes = (JSON.parse(total[0]) % groupSize);
				$("#stats-round").html("Group size: " + groupSize + " votes: " + data);
			});	
	});

});


var Animation = {
	start: function(ratio){
		var ctx = canvas.getContext('2d'),
		    w, h;

		canvas.width = w = window.innerWidth * 1.1;
		canvas.height = h = window.innerHeight * 1;

		var osc1 = new osc(),
		    osc2 = new osc(),
		    osc3 = new osc(),
		    horizon = h * ratio;
		    count = 40,
		    step = Math.ceil(w / count),
		    buffer = new ArrayBuffer(count * 4),
		    points = new Float32Array(buffer);

		osc1.max = 5;

		osc2.max = 2;
		osc2.speed = 0.01;

		osc2.max = 2;
		osc2.speed = 0.005;

		function fill() {
		    for(var i = 0; i < count; i++) {
		        points[i] = mixer(osc1, osc2, osc3);
		    }
		}
		fill();

		ctx.lineWidth = 20;
		ctx.strokeStyle = '#1d96d3';
		ctx.fillStyle = '#1d96d3';

		function loop() {

		    var i;

		    /// move points to the left
		    for(i = 0; i < count - 1; i++) {
		        points[i] = points[i + 1];
		    }

		    /// get a new point
		    points[count - 1] = mixer(osc1, osc2, osc3);

		    ctx.clearRect(0, 0, w, h);
		    //ctx.fillRect(0, 0, w, h);

		    /// render wave
		    ctx.beginPath();
		    ctx.moveTo(-5, points[0]);

		    for(i = 1; i < count; i++) {
		        ctx.lineTo(i * step, points[i]);
		    }

		    ctx.lineTo(w, h);
		    ctx.lineTo(-5, h);
		    ctx.lineTo(-5, points[1]);

		    ctx.stroke();
		    ctx.fill();
		}

		function osc() {

		    this.variation = 0.4;
		    this.max = 20;
		    this.speed = 0.02;

		    var me = this,
		        a = 0,
		        max = getMax();

		    this.getAmp = function() {

		        a += this.speed;

		        if (a >= 2.0) {
		            a = 0;
		            max = getMax();
		        }
		        return max * Math.sin(a * Math.PI);
		    }

		    function getMax() {
		        return Math.random() * me.max * me.variation +
		            me.max * (1 - me.variation);
		    }
		    return this;
		}

		function mixer() {

		    var d = arguments.length,
		        i = d,
		        sum = 0;

		    if (d < 1) return 0;

		    while(i--) sum += arguments[i].getAmp();

		    return sum / d + horizon;
		}

		var update = false;

		(function animloop(){
		    requestAnimFrame(animloop);
		    loop();
		})();

		$("#full").click(function(){
		    $(".center").hide();
		    console.log(votes);
		    Api.vote(1);
		    if(groupSize === votes+1){
		    	Api.screenshot();
		    }
		    $(".thanks").show();
		});

		$("#empty").click(function(){
		    $(".center").hide();
		    Api.vote(0);
		    if(groupSize === votes+1){
		    	Api.screenshot();
		    }
		    $(".thanks").show();
		});
	}
}

var Api = {
	vote: function(vote){
		return $.get("api.php?method=vote&vote=" + vote)
			.done(function(){
				console.log("done");
		});
	},
	screenshot: function(){
		var canvas = document.getElementById("canvas");
		var data = canvas.toDataURL("image/png");
		$.post("api.php?method=screenshot", {'data': data});
	},
	totalCount: function(){
		return $.get("api.php?method=count").done(function(result){
			$("#stats-total").html("Total votes: " + JSON.parse(result));
		});
	},
	groupCount: function(size){
		return $.get("api.php?method=group&size=" + size).done(function(result){
			console.log(JSON.parse(result));
		});
	},
	fullCount: function(){
		return $.get("api.php?method=full").done(function(result){
			$("#stats-full").html("Glass full: " + JSON.parse(result));
		});
	},
	emptyCount: function(){
		return $.get("api.php?method=empty").done(function(result){
			$("#stats-empty").html("Glass empty: " + JSON.parse(result));
		});
	}
}