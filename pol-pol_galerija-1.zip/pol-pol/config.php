<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'itboxcom_root');
define('DB_PASSWORD', 'Zerocool2!');
define('DB_DATABASE', 'itboxcom_pol-pol');
?>
