<?php

require "api.php";

$galerija = $database->getImages();
?>

<!DOCTYPE html>
<html>
<head>
<style>
div.img {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    width: 400px;
}

div.img:hover {
    border: 1px solid #777;
}

div.img img {
    width: 100%;
}

div.desc {
    padding: 15px;
    text-align: center;
}
</style>
</head>
<body>

<?php
$grupa = 0;
foreach($galerija as $slika){
$grupa++;
echo "<div class='img'>";
echo "<img src='$slika' width='400' height='400'>";
echo "<div class='desc'>Groupa $grupa</div>";
echo "</div>";
}

?>

 


</body>
</html>